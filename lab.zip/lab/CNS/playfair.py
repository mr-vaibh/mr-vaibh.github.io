def playfair_encrypt(text, key):
    # Prepare key matrix (5x5)
    key = key.upper().replace("J", "I")
    alphabet = "ABCDEFGHIKLMNOPQRSTUVWXYZ"
    matrix = []
    for c in key + alphabet:
        if c not in matrix:
            matrix.append(c)
    matrix = [matrix[i:i+5] for i in range(0, 25, 5)]

    # Helper: get position of a letter
    def pos(ch):
        for r in range(5):
            for c in range(5):
                if matrix[r][c] == ch:
                    return r, c

    # Prepare text: uppercase, replace J→I, insert X between double letters, pad if needed
    text = text.upper().replace("J", "I")
    clean = ""
    i = 0
    while i < len(text):
        a = text[i]
        b = text[i+1] if i+1 < len(text) else "X"
        if a == b:
            clean += a + "X"
            i += 1
        else:
            clean += a + b
            i += 2
    if len(clean) % 2 != 0:
        clean += "X"

    # Encrypt pairs
    result = ""
    for i in range(0, len(clean), 2):
        a, b = clean[i], clean[i+1]
        r1, c1 = pos(a)
        r2, c2 = pos(b)
        if r1 == r2:
            result += matrix[r1][(c1+1)%5] + matrix[r2][(c2+1)%5]
        elif c1 == c2:
            result += matrix[(r1+1)%5][c1] + matrix[(r2+1)%5][c2]
        else:
            result += matrix[r1][c2] + matrix[r2][c1]
    return result

# Example
print(playfair_encrypt("HELLO", "KEYWORD"))
