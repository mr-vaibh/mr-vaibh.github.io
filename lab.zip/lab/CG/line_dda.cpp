#include <graphics.h> 
#include <stdio.h>   
#include <math.h>     
#include <dos.h>      
#include <conio.h>

void DDALine(int x1, int y1, int x2, int y2) {
    float dx, dy, steps;
    float x_increment, y_increment;
    float x, y;
    int i;
    
    dx = x2 - x1;
    dy = y2 - y1;

 
    if (abs(dx) > abs(dy)) {
        steps = abs(dx);
    } else {
        steps = abs(dy);
    }

   
    x_increment = dx / steps;
    y_increment = dy / steps;

    
    x = x1;
    y = y1;

   
    for (i = 0; i <= steps; i++) {
        putpixel(round(x), round(y), WHITE); 	
        x += x_increment;                     
        y += y_increment;                    
        delay(10);                           
    }
}

int main() {
    int gd = DETECT, gm; 
    int x1, y1, x2, y2;

   
    initgraph(&gd, &gm, "c:\\tc\\bgi"); 

    printf("Enter the starting coordinates (x1 y1): ");
    scanf("%d %d", &x1, &y1);
    printf("Enter the ending coordinates (x2 y2): ");
    scanf("%d %d", &x2, &y2);

    DDALine(x1, y1, x2, y2);

    getch();     
    closegraph(); 
    return 0;
}

