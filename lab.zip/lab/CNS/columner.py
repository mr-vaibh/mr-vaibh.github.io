def columnar_encrypt(text, key):
    text = text.replace(" ", "").upper()
    key = key.upper()

    order = sorted(range(len(key)), key=lambda k: key[k])

    rows = []
    for i in range(0, len(text), len(key)):
        row = list(text[i:i+len(key)])
        if len(row) < len(key):  # pad last row
            row += ['X'] * (len(key) - len(row))
        rows.append(row)

    ciphertext = ""
    for col in order:
        for row in rows:
            ciphertext += row[col]

    return ciphertext

print(columnar_encrypt("HELLO WORLD", "KEY"))
