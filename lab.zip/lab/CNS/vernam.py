

def vernam_encrypt(plaintext, key):
    if len(key) != len(plaintext):
        raise ValueError("Key must be the same length as plaintext")
    
    ciphertext = ""
    for p, k in zip(plaintext, key):
        c = chr(ord(p) ^ ord(k))
        ciphertext += c
    return ciphertext


plaintext = "hello"
key = "XMCKL"

ciphertext = vernam_encrypt(plaintext, key)
print("Ciphertext:", ciphertext)

decrypted = vernam_encrypt(ciphertext, key)
print("Decrypted text:", decrypted)