
def get_shift(c):
    return ord(c.lower()) - ord('a')

def caesar_encrypt(text, key_char):
    shift = get_shift(key_char)
    result = []

    for char in text:
        if char.isalpha():
            base = ord('a') if char.islower() else ord('A')
            result.append(chr((ord(char) - base + shift) % 26 + base))
        else:
            result.append(char)

    return ''.join(result)


plaintext = input("Enter text to encrypt with Caesar cipher: ")
key_char = input("Enter a single character key for Caesar cipher: ")
print("Encrypted:", caesar_encrypt(plaintext, key_char))