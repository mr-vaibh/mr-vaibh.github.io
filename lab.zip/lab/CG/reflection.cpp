#include <graphics.h>
#include <stdio.h>
#include <math.h>
#include <conio.h>
void multiplyMatrix(float a[3][3], float b[3][1], float result[3][1]) {
    for (int i = 0; i < 3; i++) {
        result[i][0] = 0;
        for (int j = 0; j < 3; j++)
            result[i][0] += a[i][j] * b[j][0];
    }
}

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "C:\\TC\\BGI");

    int n, i, choice;
    float points[20][3], reflected[20][2];
    float reflect[3][3], result[3][1];

    printf("Enter number of vertices of polygon: ");
    scanf("%d", &n);

    printf("Enter coordinates (x y) of polygon:\n");
    for (i = 0; i < n; i++) {
        scanf("%f%f", &points[i][0], &points[i][1]);
        points[i][2] = 1;
    }

    cleardevice();
    setcolor(LIGHTGRAY);
    line(320, 0, 320, 480); // Y-axis
    line(0, 240, 640, 240); // X-axis
    outtextxy(325, 5, "+Y");
    outtextxy(325, 460, "-Y");
    outtextxy(10, 245, "-X");
    outtextxy(610, 245, "+X");
    for (i = 0; i < n; i++) {
        points[i][0] += 320;  
        points[i][1] = 240 - points[i][1];
    }

    setcolor(WHITE);
    for (i = 0; i < n - 1; i++)
        line(points[i][0], points[i][1], points[i + 1][0], points[i + 1][1]);
    line(points[n - 1][0], points[n - 1][1], points[0][0], points[0][1]);
    outtextxy(20, 20, "White: Original Polygon");

    printf("\nChoose Reflection Axis:\n");
    printf("1. X-axis\n2. Y-axis\n3. Line y=x\n4. Line y=-x\n");
    scanf("%d", &choice);
    switch (choice) {
        case 1: // X-axis
            reflect[0][0] = 1; reflect[0][1] = 0; reflect[0][2] = 0;
            reflect[1][0] = 0; reflect[1][1] = -1; reflect[1][2] = 0;
            reflect[2][0] = 0; reflect[2][1] = 0; reflect[2][2] = 1;
            break;
        case 2: // Y-axis
            reflect[0][0] = -1; reflect[0][1] = 0; reflect[0][2] = 0;
            reflect[1][0] = 0; reflect[1][1] = 1; reflect[1][2] = 0;
            reflect[2][0] = 0; reflect[2][1] = 0; reflect[2][2] = 1;
            break;
        case 3: // y = x
            reflect[0][0] = 0; reflect[0][1] = 1; reflect[0][2] = 0;
            reflect[1][0] = 1; reflect[1][1] = 0; reflect[1][2] = 0;
            reflect[2][0] = 0; reflect[2][1] = 0; reflect[2][2] = 1;
            break;
        case 4: // y = -x
            reflect[0][0] = 0; reflect[0][1] = -1; reflect[0][2] = 0;
            reflect[1][0] = -1; reflect[1][1] = 0; reflect[1][2] = 0;
            reflect[2][0] = 0; reflect[2][1] = 0; reflect[2][2] = 1;
            break;
        default:
            printf("Invalid choice!");
            closegraph();
            return 0;
    }
    for (i = 0; i < n; i++) {
        float temp[3][1] = {
            {points[i][0] - 320},
            {240 - points[i][1]},
            {1}
        };
        multiplyMatrix(reflect, temp, result);
        reflected[i][0] = result[0][0] + 320;
        reflected[i][1] = 240 - result[1][0];
    }
    setcolor(YELLOW);
    for (i = 0; i < n - 1; i++)
        line(reflected[i][0], reflected[i][1], reflected[i + 1][0], reflected[i + 1][1]);
    line(reflected[n - 1][0], reflected[n - 1][1], reflected[0][0], reflected[0][1]);
    outtextxy(20, 40, "Yellow: Reflected Polygon");
    getch();
    closegraph();
    return 0;
}
