#include <graphics.h>
#include <conio.h>
#include <stdio.h>
#include <math.h>

int main()
{
    int gd = DETECT, gm;
    int n, i;
    float a[10][3], result[10][3];
    float angle, rad;
    float rot[3][3];
    int choice;
    float xr = 0, yr = 0; 

    initgraph(&gd, &gm, "C:\\TC\\BGI");

    printf("Enter number of vertices of polygon: ");
    scanf("%d", &n);

    printf("Enter coordinates (x y) of polygon:\n");
    for (i = 0; i < n; i++)
    {
        printf("Point %d: ", i + 1);
        scanf("%f %f", &a[i][0], &a[i][1]);
        a[i][2] = 1;
    }

    printf("Enter rotation angle (in degrees): ");
    scanf("%f", &angle);

    printf("Rotate about:\n1. Origin (0,0)\n2. A specific point\nEnter choice: ");
    scanf("%d", &choice);

    if (choice == 2)
    {
        printf("Enter rotation point (xr, yr): ");
        scanf("%f %f", &xr, &yr);
    }

    cleardevice(); 

   
    setcolor(WHITE);
    for (i = 0; i < n - 1; i++)
        line(a[i][0], a[i][1], a[i + 1][0], a[i + 1][1]);
    line(a[n - 1][0], a[n - 1][1], a[0][0], a[0][1]);

    
    rad = angle * (3.14159 / 180);

    
    rot[0][0] = cos(rad);
    rot[0][1] = -sin(rad);
    rot[0][2] = 0;
    rot[1][0] = sin(rad);
    rot[1][1] = cos(rad);
    rot[1][2] = 0;
    rot[2][0] = 0;
    rot[2][1] = 0;
    rot[2][2] = 1;

   
    for (i = 0; i < n; i++)
    {
        if (choice == 2)
        {
            a[i][0] -= xr;
            a[i][1] -= yr;
        }

        
        result[i][0] = a[i][0] * rot[0][0] + a[i][1] * rot[0][1] + a[i][2] * rot[0][2];
        result[i][1] = a[i][0] * rot[1][0] + a[i][1] * rot[1][1] + a[i][2] * rot[1][2];
        result[i][2] = 1;

        if (choice == 2)
        {
            result[i][0] += xr;
            result[i][1] += yr;
        }
    }

   
    setcolor(YELLOW);
    for (i = 0; i < n - 1; i++)
        line(result[i][0], result[i][1], result[i + 1][0], result[i + 1][1]);
    line(result[n - 1][0], result[n - 1][1], result[0][0], result[0][1]);

   
    setcolor(WHITE);
    outtextxy(50, 20, "White: Original Polygon");
    setcolor(YELLOW);
    outtextxy(50, 40, "Yellow: Rotated Polygon");

    getch();
    closegraph();
    return 0;
}
