
def get_shift(c):
    return ord(c.lower()) - ord('a')

def vigenere_encrypt(text, key):
    result = []
    key_length = len(key)
    key_index = 0

    for char in text:
        if char.isalpha():
            shift = get_shift(key[key_index % key_length])
            base = ord('a') if char.islower() else ord('A')
            result.append(chr((ord(char) - base + shift) % 26 + base))
            key_index += 1
        else:
            result.append(char)

    return ''.join(result)

plaintext = input("Enter text to encrypt: ")
key = input("Enter key: ")
print("Encrypted:", vigenere_encrypt(plaintext, key))
