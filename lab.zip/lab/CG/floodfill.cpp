#include<conio.h>
#include<stdio.h>
#include<graphics.h>
#include<dos.h>

void fill_right(int x,int y)
{
if(getpixel(x,y) == 0)
{
putpixel(x,y,RED);
fill_right(++x,y);
x = x - 1 ;
fill_right(x,y-1);
fill_right(x,y+1);

}
}
void fill_left(int x,int y)
{
if(getpixel(x,y) == 0)
{
putpixel(x,y,RED);

fill_left(--x,y);
x = x + 1 ;
fill_left(x,y-1);
fill_left(x,y+1);

}
}
int main()
{
	int x, y, a[20][2];
	int gd, gm, n, i;

	detectgraph(&gd, &gm);
	initgraph(&gd, &gm, "c:\\tc\\bgi");

printf("\n\n\tEnter the no. of edges of polygon : ");
scanf("%d",&n);
printf("\n\n\tEnter the cordinates of polygon :\n\n\n ");

	for (i = 0; i < n; i++)
	{
		printf("\tX%d Y%d : ", i, i);
		scanf("%d %d", &a[i][0], &a[i][1]);
	}

	a[n][0] = a[0][0];
	a[n][1] = a[0][1];
	printf("\n\n\tEnter the seed pt. : ");
	scanf("%d%d", &x, &y);
	cleardevice();
	setcolor(WHITE);

	for (i = 0; i < n; i++)
	{
		line(a[i][0], a[i][1], a[i + 1][0], a[i + 1][1]);
	}

	fill_right(x, y);
	fill_left(x - 1, y);

	getch();
	closegraph();
	return 0;

}