#include <graphics.h>
#include <conio.h>
#include <stdio.h>

int main()
{
    int gd = DETECT, gm;
    int n, i;
    int a[10][3];        // Original polygon points
    int trans[3][3];     // Translation matrix
    int result[10][3];   // Resultant translated points
    int tx, ty;

    initgraph(&gd, &gm, "C:\\TC\\BGI");

    printf("Enter number of vertices of polygon: ");
    scanf("%d", &n);

    printf("Enter coordinates (x y) of polygon:\n");
    for (i = 0; i < n; i++)
    {
        printf("Point %d: ", i + 1);
        scanf("%d %d", &a[i][0], &a[i][1]);
        a[i][2] = 1; // Homogeneous coordinate
    }

    printf("Enter translation factors (tx, ty): ");
    scanf("%d %d", &tx, &ty);

    // Define translation matrix
    trans[0][0] = 1; trans[0][1] = 0; trans[0][2] = tx;
    trans[1][0] = 0; trans[1][1] = 1; trans[1][2] = ty;
    trans[2][0] = 0; trans[2][1] = 0; trans[2][2] = 1;

    cleardevice();

    // Draw original polygon in WHITE
    setcolor(WHITE);
    for (i = 0; i < n - 1; i++)
        line(a[i][0], a[i][1], a[i + 1][0], a[i + 1][1]);
    line(a[n - 1][0], a[n - 1][1], a[0][0], a[0][1]);

    // Multiply each vertex by translation matrix (row-wise)
    for (i = 0; i < n; i++)
    {
        result[i][0] = a[i][0] * trans[0][0] + a[i][1] * trans[0][1] + a[i][2] * trans[0][2];
        result[i][1] = a[i][0] * trans[1][0] + a[i][1] * trans[1][1] + a[i][2] * trans[1][2];
        result[i][2] = a[i][0] * trans[2][0] + a[i][1] * trans[2][1] + a[i][2] * trans[2][2];
    }

    // Draw translated polygon in YELLOW
    setcolor(YELLOW);
    for (i = 0; i < n - 1; i++)
        line(result[i][0], result[i][1], result[i + 1][0], result[i + 1][1]);
    line(result[n - 1][0], result[n - 1][1], result[0][0], result[0][1]);

    // Labels
    setcolor(LIGHTGREEN);
    outtextxy(20, 20, "White: Original Polygon");
    outtextxy(20, 40, "Yellow: Translated Polygon");

    getch();
    closegraph();
    return 0;
}
