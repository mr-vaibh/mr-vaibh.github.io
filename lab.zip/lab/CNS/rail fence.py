def rail_fence_encrypt(text, rails):
    text = text.replace(" ", "").upper()
    fence = [[] for _ in range(rails)]
    rail = 0
    direction = 1  # 1 = down, -1 = up

    for ch in text:
        fence[rail].append(ch)
        rail += direction
        if rail == 0 or rail == rails - 1:
            direction *= -1  # change direction at top/bottom

    # Read row by row
    return ''.join(''.join(row) for row in fence)

# Example
print(rail_fence_encrypt("HELLO WORLD", 3))
